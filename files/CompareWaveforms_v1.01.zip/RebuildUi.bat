rem Rebuild the UI Python links after mods in Qt Designer
@echo off
%PYUICDIR%\pyuic4.bat CompareWaveforms.ui -o ui_CompareWaveforms.py