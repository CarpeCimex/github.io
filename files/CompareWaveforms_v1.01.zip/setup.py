# From a command prompt in the project folder, run 'python setup.py bdist_msi'
# to create an install package (.msi)
import sys
from cx_Freeze import setup, Executable

# Dependencies are automatically detected, but it might need fine tuning.
build_exe_options = {"packages": ["os"], "excludes": ["tkinter"]}

# GUI applications require a different base on Windows (the default is for a
# console application).
base = None
if sys.platform == "win32":
    base = "Win32GUI"

setup(  name = "CompareWaveforms",
        version = "1.0",
        description = "Compare LTspice and oscilloscope waveforms",
        options = {"build_exe": build_exe_options},
        executables = [Executable("CompareWaveforms.pyw", base=base)])
