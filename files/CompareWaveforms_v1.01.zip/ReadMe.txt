CompareWaveforms v1.01
Gerrit Barrere -- www.exality.com -- 29 Dec 2014
Utility to compare an LTspice simulation waveform with a scope waveform.

The UI was developed with QT Designer v4.8.6, available open source from http://sourceforge.net/projects/pyqt/ .  This produces the CompareWaveforms.ui file, which is compiled to the ui_CompareWaveforms.py script by running RebuildUi.bat after each change to the UI.

mplwidget.py is imported by ui_CompareWaveforms.py, and provides the definition for the 'mplwidget' object in the UI (the plot region).  It links the UI to the graphical output provided by matplotlib in Python.

The main script is CompareWaveforms.pyw, written with Python 3.4 (available open source from www.python.org).  It is a .pyw file which means no console window appears when it is run from Windows.

setup.py is used with the Python cx_freeze package to create a self-contained .exe.

You can see a quick demo of CompareWaveforms by starting the program, selecting LTspiceSample.txt as your LTspice file, ScopeSample.csv as your scope file, and pressing 'Compare'.  Now you can move the long slider along the bottom to line up the waveforms, and press 'Save .png' to save the plot.