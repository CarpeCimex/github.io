# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'CompareWaveforms.ui'
#
# Created: Fri Dec 19 14:09:36 2014
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(796, 561)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(_fromUtf8("../../Web Pages/WebPlus/FavIcon.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        MainWindow.setUnifiedTitleAndToolBarOnMac(False)
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.mpl = MplWidget(self.centralwidget)
        self.mpl.setGeometry(QtCore.QRect(10, 100, 771, 381))
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.mpl.sizePolicy().hasHeightForWidth())
        self.mpl.setSizePolicy(sizePolicy)
        self.mpl.setObjectName(_fromUtf8("mpl"))
        self.pushButtonSave = QtGui.QPushButton(self.centralwidget)
        self.pushButtonSave.setGeometry(QtCore.QRect(320, 520, 151, 31))
        self.pushButtonSave.setObjectName(_fromUtf8("pushButtonSave"))
        self.sliderSkew = QtGui.QSlider(self.centralwidget)
        self.sliderSkew.setGeometry(QtCore.QRect(9, 490, 771, 20))
        self.sliderSkew.setMinimum(-200)
        self.sliderSkew.setMaximum(200)
        self.sliderSkew.setOrientation(QtCore.Qt.Horizontal)
        self.sliderSkew.setObjectName(_fromUtf8("sliderSkew"))
        self.lineEditLtsFile = QtGui.QLineEdit(self.centralwidget)
        self.lineEditLtsFile.setGeometry(QtCore.QRect(100, 10, 500, 20))
        self.lineEditLtsFile.setReadOnly(True)
        self.lineEditLtsFile.setObjectName(_fromUtf8("lineEditLtsFile"))
        self.lineEditScopeFile = QtGui.QLineEdit(self.centralwidget)
        self.lineEditScopeFile.setGeometry(QtCore.QRect(100, 40, 500, 20))
        self.lineEditScopeFile.setReadOnly(True)
        self.lineEditScopeFile.setObjectName(_fromUtf8("lineEditScopeFile"))
        self.lineEditPlotPath = QtGui.QLineEdit(self.centralwidget)
        self.lineEditPlotPath.setGeometry(QtCore.QRect(100, 70, 500, 20))
        self.lineEditPlotPath.setReadOnly(True)
        self.lineEditPlotPath.setObjectName(_fromUtf8("lineEditPlotPath"))
        self.pushButtonCompare = QtGui.QPushButton(self.centralwidget)
        self.pushButtonCompare.setGeometry(QtCore.QRect(620, 12, 75, 51))
        self.pushButtonCompare.setObjectName(_fromUtf8("pushButtonCompare"))
        self.pushButtonLtsFile = QtGui.QPushButton(self.centralwidget)
        self.pushButtonLtsFile.setGeometry(QtCore.QRect(10, 10, 81, 23))
        self.pushButtonLtsFile.setObjectName(_fromUtf8("pushButtonLtsFile"))
        self.pushButtonScopeFile = QtGui.QPushButton(self.centralwidget)
        self.pushButtonScopeFile.setGeometry(QtCore.QRect(10, 40, 81, 23))
        self.pushButtonScopeFile.setObjectName(_fromUtf8("pushButtonScopeFile"))
        self.pushButtonPlotPath = QtGui.QPushButton(self.centralwidget)
        self.pushButtonPlotPath.setGeometry(QtCore.QRect(10, 70, 75, 23))
        self.pushButtonPlotPath.setObjectName(_fromUtf8("pushButtonPlotPath"))
        MainWindow.setCentralWidget(self.centralwidget)
        self.actionLTspiceFile = QtGui.QAction(MainWindow)
        self.actionLTspiceFile.setObjectName(_fromUtf8("actionLTspiceFile"))
        self.actionScopeFile = QtGui.QAction(MainWindow)
        self.actionScopeFile.setObjectName(_fromUtf8("actionScopeFile"))
        self.actionPlotsPath = QtGui.QAction(MainWindow)
        self.actionPlotsPath.setObjectName(_fromUtf8("actionPlotsPath"))

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "CompareWaveforms", None))
        self.pushButtonSave.setText(_translate("MainWindow", "Save .png", None))
        self.pushButtonCompare.setText(_translate("MainWindow", "Compare", None))
        self.pushButtonLtsFile.setText(_translate("MainWindow", "LTspice file", None))
        self.pushButtonScopeFile.setText(_translate("MainWindow", "Scope file", None))
        self.pushButtonPlotPath.setText(_translate("MainWindow", "Plot path", None))
        self.actionLTspiceFile.setText(_translate("MainWindow", "LTspice", None))
        self.actionScopeFile.setText(_translate("MainWindow", "Scope", None))
        self.actionPlotsPath.setText(_translate("MainWindow", "Plots", None))

from mplwidget import MplWidget
