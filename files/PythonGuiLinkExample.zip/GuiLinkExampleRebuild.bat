rem Rebuild the 'GuiLinkExample' UI project after mods in Qt Designer
@echo off
python "%WINPYDIR%\Lib\site-packages\PyQt4\uic\pyuic.py" GuiLinkExample.ui -o GuiLinkExample.py