# -*- coding: utf-8 -*-
"""
Created on Thu Sep  4 17:42:24 2014

@author: Gerrit
"""
# QtCore not needed?
from PyQt4 import QtCore, QtGui
# Import the main GUI form from the .py file generated
# by pyuic.  Change Dialog to Widget or MainWindow depending
# on original widget in Qt Designer:
from GuiLinkExample import Ui_Dialog

#=========================================================
# Non-GUI logic to link to GUI:
def calcSum(u,v):
    return ( u + v )
#=========================================================
# Appended code to run the GUI and link to it.
# Change Dialog to Widget or MainWindow, depending on
# the original widget type in Qt Designer.
class Window(QtGui.QDialog):
    def __init__(self):
        QtGui.QDialog.__init__(self)
        # object created in GuiLinkExample.py:
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        # connect to actions in GUI
        self.ui.butSum.clicked.connect(self.doSum)

    # Actions initiated from the GUI:
    def doSum(self):
        # get data from input boxes in GUI:        
        u = int(str(self.ui.txtLine.text()))
        v = int(str(self.ui.txtLine_2.text()))
        # call logic defined above
        w = calcSum(u,v)
        # output to GUI:
        self.ui.txtLine_3.setText(str(w))

# This creates the GUI window:
if __name__ == '__main__':

    import sys
    app = QtGui.QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec_())
#=========================================================
