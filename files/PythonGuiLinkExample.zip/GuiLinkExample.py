# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'GuiLinkExample.ui'
#
# Created: Thu Sep  4 18:18:15 2014
#      by: PyQt4 UI code generator 4.9.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(235, 118)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.txtLine = QtGui.QLineEdit(Dialog)
        self.txtLine.setObjectName(_fromUtf8("txtLine"))
        self.gridLayout.addWidget(self.txtLine, 0, 0, 1, 1)
        self.txtLine_2 = QtGui.QLineEdit(Dialog)
        self.txtLine_2.setObjectName(_fromUtf8("txtLine_2"))
        self.gridLayout.addWidget(self.txtLine_2, 1, 0, 1, 1)
        self.butSum = QtGui.QPushButton(Dialog)
        self.butSum.setObjectName(_fromUtf8("butSum"))
        self.gridLayout.addWidget(self.butSum, 1, 1, 2, 1)
        self.txtLine_3 = QtGui.QLineEdit(Dialog)
        self.txtLine_3.setObjectName(_fromUtf8("txtLine_3"))
        self.gridLayout.addWidget(self.txtLine_3, 2, 0, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.butSum.setText(_translate("Dialog", "Sum", None))

