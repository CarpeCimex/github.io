import os
import sys
sys.path.append('../..')

file_list = os.listdir()
models = []
for file in file_list:
    if file.endswith(".py") and not ("ModelConvert" in file):
        models.append(file)

# Test a single file
#for file in ["ls(cpr).py"]:
for file in models:
    print(file)
    trans = []
    names = []
    with open(file, mode='r', encoding='utf-8', newline=None) as f:
        line = next(f)
        # Skip normalization instructions in param comments
        while "# with all fitting methods." not in line:
            trans.append(line)
            line = next(f)
        trans.append("# with all fitting methods.\n")
        line = next(f)
        line = next(f)
        line = next(f)

        # Skip normalization instructions in model function
        while "Do not put fixed R, L, or C" not in line:
            trans.append(line)
            line = next(f)
        line = next(f)
        line = next(f)

        # Copy remainder of file
        while line:
            trans.append(line)
            try:
                line = next(f)
            except:
                break
    # Write to test file
    #with open(file, mode='w', encoding='utf-8', newline=None) as f:
    with open(file, mode='w', encoding='utf-8', newline=None) as f:
        for line in trans:
            # Test printing results instead of rewriting file
            #print(line)
            f.write(line)