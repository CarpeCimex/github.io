import os
import sys
sys.path.append('../..')
from utils import eng_notate
import math
import numpy as np

# Convert +/-np.inf to +/-1e12 for compatibility with differential_evolution fitting method

def bound_inf(x):
    switch = {
        np.inf: 1e12,
        -np.inf: -1e12
    }
    return switch.get(x, x)

file_list = os.listdir()
models = []
for file in file_list:
    if file.endswith(".py") and file != os.path.basename(__file__):
        models.append(file)

#models = ["csrsl.py"]
for file in models:
    print(file)
    trans = []
    names = []
    with open(file, mode='r', encoding='utf-8', newline=None) as f:
        line = next(f)
        while "from collections" not in line:
            trans.append(line)
            line = next(f)
        line = next(f)
        while "# Ordered dictionary" not in line:
            trans.append(line)
            line = next(f)
        for i in range(8):
            # Discard up through comment line of PARAMS dict
            line = next(f)
        # New comments
        trans.append("# Dictionary of parameter names, initial values, and min/max\n")
        trans.append("# bounds.  Set 'vary'=False to hold a parameter constant.\n")
        trans.append("# Use large +/- number for unbounded param to remain compatible\n")
        trans.append("# with all fitting methods.  Use R, L, or C as first letter\n")
        trans.append("# for resistor, inductor, or capacitor names to allow automatic\n")
        trans.append("# normalizing & denormalizing outside the model.\n")
        # Translate old PARAMS to new
        trans.append("PARAMS = [\n")
        while "])" not in line:
            # Translate line into actual tuple
            t = eval(line)
            t = t[0]
            name = t[0]
            names.append(name)
            init = eng_notate(t[1][0], suff=False, neg_ok=True)
            x = bound_inf(t[1][1][0])
            min = eng_notate(x, suff=False, neg_ok=True)
            x = bound_inf(t[1][1][1])
            max = eng_notate(x, suff=False, neg_ok=True)
            max = bound_inf(max)
            trans.append('    {{"name": "{0}", "init": {1:>8s}, "vary": True, "min": {2:>8s}, "max": {3:>8s}}},\n'.format(
                name, init, min, max))
            line = next(f)
        line = next(f)
        trans.append("]\n")
        while "def model" not in line:
            trans.append(line)
            line = next(f)
        line = next(f)
        line = next(f)
        while '"""' not in line:
            # Discard through end of comment header for model function
            line = next(f)
        line = next(f)
        # New model function line and comments
        trans.append("def model(w, load, params):\n")
        trans.append('    """\n')
        trans.append("    Calculate impedance using equations here for all frequencies w.\n")
        trans.append("    Do not put fixed R, L, or C values in the model or it will prevent\n")
        trans.append("    necessary normalizing & denormalizing outside the model.\n")
        trans.append("    :param w: radian frequency array\n")
        trans.append("    :param load: optional array of complex load values corresponding to w\n")
        trans.append("    :param params: list of component values to apply to the model equations\n")
        trans.append("    :return: complex impedance array corresponding to freqs w\n")
        trans.append('    """\n')
        while "= params" not in line:
            trans.append(line)
            line = next(f)
        line = next(f)
        trans.append("    # CHECK PARAMETER TRANSLATION:\n")
        for n in names:
            trans.append("    {0} = params['{0}'].value\n".format(n))
        while line:
            trans.append(line)
            try:
                line = next(f)
            except:
                break
    with open(file, mode='w', encoding='utf-8', newline=None) as f:
        for line in trans:
            f.write(line)